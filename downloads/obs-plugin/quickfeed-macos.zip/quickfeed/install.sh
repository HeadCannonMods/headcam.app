#!/bin/bash
cd "$(dirname "$0")"

echo "Installing QuickFeed OBS Plugin..."

PLUGIN_DIR="$HOME/Library/Application Support/obs-studio/plugins"

mkdir -p "$PLUGIN_DIR"
rm -rf "$PLUGIN_DIR/quickfeed.plugin"
cp -r quickfeed.plugin "$PLUGIN_DIR/"

echo "Installed to: $PLUGIN_DIR/quickfeed.plugin"
echo "Restart OBS to use QuickFeed."
