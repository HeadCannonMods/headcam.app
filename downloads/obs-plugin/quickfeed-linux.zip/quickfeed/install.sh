#!/bin/bash
cd "$(dirname "$0")"

echo "Installing QuickFeed OBS Plugin..."

PLUGIN_DIR="$HOME/.config/obs-studio/plugins/quickfeed"

mkdir -p "$PLUGIN_DIR"
cp -r bin "$PLUGIN_DIR/"
cp -r data "$PLUGIN_DIR/"

echo ""
echo "Done! Plugin installed to:"
echo "$PLUGIN_DIR"
echo ""
echo "Restart OBS to use QuickFeed."
